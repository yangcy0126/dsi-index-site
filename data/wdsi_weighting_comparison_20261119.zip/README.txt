International WDSI weighting comparison | November 19, 2026
Companion to Diplomatic Sentiment and International Capital Flows: Do Words Move Money?

This is a same-sample check of the paper's international results, not a change
to the paper or a regression on the extended website data. Only the WDSI and
factors derived from it change. Financial outcomes, periods, controls,
seasonal effects and inference follow the original specification.

Method
Both daily indices cover the date shown and the preceding 13 calendar days.
paper_day: take the most adverse document each publication day, carry the
daily score across silent days, then average 14 equally weighted daily scores.
document: divide the sum of all accepted record scores in the window by the
number of those records, including zeros. Carry the last valid window mean
only across wholly empty windows. Positive WDSI denotes more adverse rhetoric.
Both monthly and quarterly signals are arithmetic means of available daily
index values; neither construction pools all documents for an entire quarter.
In Korea the historical document roster was reconstructed using the original
collection rules. It reproduces all 5,951 original daily stances, which does
not uniquely identify the historical document list. Using the complete Korean
score archive also leaves its main monthly debt net-flow estimate insignificant
and its quarterly estimate negative and significant at 5%.

Files
historical_index_periods.csv: all 15 countries. wdsi14_countryday and
wdsi14_document are paired HISTORICAL period means, not the current site
vintage. M = calendar month, Q = quarter; date is the period start.
signal_days counts available daily indices; required_days is the number of
calendar days in the full period. full_signal_period compares the two counts.
These are candidate signal periods, not every model's financial observations.

transaction_estimates.csv: all available non-U.S. country/asset/frequency
combinations for equity and fund shares, debt securities, and total portfolio
transactions. in = nonresidents' net purchases of domestic securities;
out = residents' net purchases of foreign securities; net = in minus out
before transformation. ihs_usd_million = asinh(flow in USD millions);
ihs_unit_invariant = asinh(flow / same-sample raw-flow standard deviation).
The main transaction results use ihs_usd_million and HC1 (normal reference).
HAC6 (monthly) and HAC2 (quarterly) use calendar-gap Bartlett weights and
a t reference. Results are not available for every country at both frequencies.

us_own_holdings.csv: Table 10A; 131 monthly observations. in/out are market
values of foreign holdings of U.S. equities / U.S. holdings of foreign
equities. net is the difference before transformation. These are positions
in USD millions transformed by asinh, not transactions. Main inference: HC1.
us_holdings_components.csv: Table 10B / IA.35. Equal or first principal
component (pc1) factors are re-estimated from the other 14 economies on 122
common months, November 2015 to December 2025. The fitted common part of
standardized U.S. WDSI and the U.S.-specific residual enter the same model.
common_minus_specific tests their coefficient difference. Holdings use 121
months ending November 2025; main inference is HAC6, t(99), with factors
treated as fixed. margin has the same meaning as in the own-holdings file.

For each estimate, paper_day_* and document_* are paired on identical
observations. b = coefficient; se = standard error; p = raw two-sided
p-value. n, start, end describe the financial sample, not corpus coverage.
For net transaction outcomes, bh and holm are adjusted p-values within
each asset/frequency/transformation/inference family. Blanks mean not
applicable. Total-portfolio adjustments are supplementary. A change in
significance alone is not a test of the difference between estimates.
The unchanged Stock Connect estimates in Table 4 already use document
weights and are not among the international re-estimates.
